<?php
/**
 * Plugin Name: Nurevo WebMCP Canary
 * Plugin URI: https://nurevo.jp/
 * Description: Loads the Nurevo WebMCP tag for agent-readable forms, autofill helpers, privacy-safe footprints, and A/B-tested MCP/AEO delivery.
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Nurevo
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: webmcp-canary
 * Domain Path: /languages
 *
 * @package WebMCP_Canary
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WEBMCP_CANARY_VERSION', '0.1.0');
define('WEBMCP_CANARY_OPTION', 'webmcp_canary_settings');

function webmcp_canary_default_settings() {
    return array(
        'enabled' => '0',
        'tag_url' => 'https://webmcp-canary.nurevo.workers.dev/tag.js',
        'site_key' => '',
        'site_email' => get_option('admin_email'),
        'admin_token' => '',
        'monthly_price_yen' => '3000',
    );
}

function webmcp_canary_settings() {
    $settings = get_option(WEBMCP_CANARY_OPTION, array());
    return wp_parse_args(is_array($settings) ? $settings : array(), webmcp_canary_default_settings());
}

add_action('admin_init', 'webmcp_canary_register_settings');
function webmcp_canary_register_settings() {
    register_setting('webmcp_canary', WEBMCP_CANARY_OPTION, array(
        'type' => 'array',
        'sanitize_callback' => 'webmcp_canary_sanitize_settings',
        'default' => webmcp_canary_default_settings(),
    ));

    add_settings_section(
        'webmcp_canary_main',
        __('WebMCP tag settings', 'webmcp-canary'),
        '__return_false',
        'webmcp_canary'
    );

    add_settings_field('enabled', __('Enable tag', 'webmcp-canary'), 'webmcp_canary_enabled_field', 'webmcp_canary', 'webmcp_canary_main');
    add_settings_field('tag_url', __('External tag.js URL', 'webmcp-canary'), 'webmcp_canary_tag_url_field', 'webmcp_canary', 'webmcp_canary_main');
    add_settings_field('site_key', __('API key / site key', 'webmcp-canary'), 'webmcp_canary_site_key_field', 'webmcp_canary', 'webmcp_canary_main');
    add_settings_field('site_email', __('Owner email', 'webmcp-canary'), 'webmcp_canary_site_email_field', 'webmcp_canary', 'webmcp_canary_main');
    add_settings_field('admin_token', __('Admin token', 'webmcp-canary'), 'webmcp_canary_admin_token_field', 'webmcp_canary', 'webmcp_canary_main');
    add_settings_field('monthly_price_yen', __('Locked feature price', 'webmcp-canary'), 'webmcp_canary_monthly_price_field', 'webmcp_canary', 'webmcp_canary_main');
}

function webmcp_canary_sanitize_settings($input) {
    $input = is_array($input) ? $input : array();
    return array(
        'enabled' => !empty($input['enabled']) ? '1' : '0',
        'tag_url' => isset($input['tag_url']) ? esc_url_raw($input['tag_url']) : '',
        'site_key' => isset($input['site_key']) ? sanitize_text_field($input['site_key']) : '',
        'site_email' => isset($input['site_email']) ? sanitize_email($input['site_email']) : '',
        'admin_token' => isset($input['admin_token']) ? sanitize_text_field($input['admin_token']) : '',
        'monthly_price_yen' => isset($input['monthly_price_yen']) ? (string) max(0, intval($input['monthly_price_yen'])) : '3000',
    );
}

function webmcp_canary_enabled_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<label><input type="checkbox" name="%1$s[enabled]" value="1" %2$s> %3$s</label>',
        esc_attr(WEBMCP_CANARY_OPTION),
        checked('1', $settings['enabled'], false),
        esc_html__('Load WebMCP tag on public pages', 'webmcp-canary')
    );
}

function webmcp_canary_tag_url_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<input type="url" class="regular-text code" name="%1$s[tag_url]" value="%2$s" placeholder="https://cdn.example.com/tag.js">',
        esc_attr(WEBMCP_CANARY_OPTION),
        esc_attr($settings['tag_url'])
    );
    echo '<p class="description">' . esc_html__('The plugin does not bundle tag.js. Updating this hosted file updates all installed sites.', 'webmcp-canary') . '</p>';
}

function webmcp_canary_site_key_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<input type="text" class="regular-text code" name="%1$s[site_key]" value="%2$s" autocomplete="off">',
        esc_attr(WEBMCP_CANARY_OPTION),
        esc_attr($settings['site_key'])
    );
    echo '<p class="description">' . esc_html__('Sent to the WebMCP server as a site authorization key. Do not use a privileged server secret here.', 'webmcp-canary') . '</p>';
}

function webmcp_canary_site_email_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<input type="email" class="regular-text" name="%1$s[site_email]" value="%2$s" autocomplete="email">',
        esc_attr(WEBMCP_CANARY_OPTION),
        esc_attr($settings['site_email'])
    );
    echo '<p class="description">' . esc_html__('Used only when issuing a free site key from the WebMCP server.', 'webmcp-canary') . '</p>';
}

function webmcp_canary_admin_token_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<input type="password" class="regular-text code" name="%1$s[admin_token]" value="%2$s" autocomplete="off">',
        esc_attr(WEBMCP_CANARY_OPTION),
        esc_attr($settings['admin_token'])
    );
    echo '<p class="description">' . esc_html__('Only used by this WordPress admin screen for protected management actions such as key rotation and disablement. It is never printed on public pages.', 'webmcp-canary') . '</p>';
}

function webmcp_canary_monthly_price_field() {
    $settings = webmcp_canary_settings();
    printf(
        '<input type="number" min="0" step="100" class="small-text" name="%1$s[monthly_price_yen]" value="%2$s"> <span>%3$s</span>',
        esc_attr(WEBMCP_CANARY_OPTION),
        esc_attr($settings['monthly_price_yen']),
        esc_html__('JPY / month', 'webmcp-canary')
    );
    echo '<p class="description">' . esc_html__('Display only. Billing is not implemented in this plugin version.', 'webmcp-canary') . '</p>';
}

add_action('admin_menu', 'webmcp_canary_admin_menu');
function webmcp_canary_admin_menu() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $badge_count = webmcp_canary_dashboard_badge_count();
    $menu_title = __('WebMCP', 'webmcp-canary');
    if ($badge_count > 0) {
        $menu_title .= sprintf(
            ' <span class="awaiting-mod"><span class="pending-count">%d</span></span>',
            intval($badge_count)
        );
    }

    add_menu_page(
        __('WebMCP', 'webmcp-canary'),
        $menu_title,
        'manage_options',
        'webmcp-canary',
        'webmcp_canary_dashboard_page',
        'dashicons-forms',
        58
    );

    add_submenu_page(
        'webmcp-canary',
        __('Dashboard', 'webmcp-canary'),
        __('Dashboard', 'webmcp-canary'),
        'manage_options',
        'webmcp-canary',
        'webmcp_canary_dashboard_page'
    );

    add_submenu_page(
        'webmcp-canary',
        __('Settings', 'webmcp-canary'),
        __('Settings', 'webmcp-canary'),
        'manage_options',
        'webmcp-canary-settings',
        'webmcp_canary_settings_page'
    );
}

function webmcp_canary_dashboard_badge_count() {
    $settings = webmcp_canary_settings();
    if (empty($settings['site_key'])) {
        return 0;
    }
    $api_bases = webmcp_canary_api_base_candidates();
    if (empty($api_bases)) {
        return 0;
    }
    $cache_key = 'webmcp_canary_site_insights_' . md5(implode(',', $api_bases) . '|' . $settings['site_key'] . '|' . home_url());
    $insights = get_transient($cache_key);
    if (is_wp_error($insights) || empty($insights['dataSufficiency']['sufficient'])) {
        return 0;
    }
    return isset($insights['newSuggestionCount']) ? max(0, intval($insights['newSuggestionCount'])) : 0;
}

function webmcp_canary_api_base() {
    $settings = webmcp_canary_settings();
    if (empty($settings['tag_url'])) {
        return '';
    }
    $parts = wp_parse_url($settings['tag_url']);
    if (empty($parts['scheme']) || empty($parts['host'])) {
        return '';
    }
    $port = !empty($parts['port']) ? ':' . $parts['port'] : '';
    return $parts['scheme'] . '://' . $parts['host'] . $port;
}

function webmcp_canary_api_base_candidates() {
    $api_base = webmcp_canary_api_base();
    if (empty($api_base)) {
        return array();
    }
    $candidates = array($api_base);
    $parts = wp_parse_url($api_base);
    $host = isset($parts['host']) ? strtolower($parts['host']) : '';
    if ($host === 'localhost' || $host === '127.0.0.1') {
        $scheme = !empty($parts['scheme']) ? $parts['scheme'] : 'http';
        $port = !empty($parts['port']) ? ':' . $parts['port'] : '';
        $candidates[] = $scheme . '://webmcp' . $port;
        $candidates[] = $scheme . '://host.docker.internal' . $port;
    }
    return array_values(array_unique($candidates));
}

function webmcp_canary_api_request($path, $body) {
    $api_bases = webmcp_canary_api_base_candidates();
    if (empty($api_bases)) {
        return new WP_Error('webmcp_missing_api_base', __('The tag.js URL is not configured. Open WebMCP > Settings and configure it.', 'webmcp-canary'));
    }

    $last_error = null;
    foreach ($api_bases as $api_base) {
        $settings = webmcp_canary_settings();
        $headers = array(
            'accept' => 'application/json',
            'content-type' => 'application/json',
        );
        if (!empty($settings['admin_token'])) {
            $headers['x-webmcp-admin-token'] = $settings['admin_token'];
        }
        $response = wp_remote_post(trailingslashit($api_base) . ltrim($path, '/'), array(
            'timeout' => 3,
            'headers' => $headers,
            'body' => wp_json_encode($body),
        ));
        if (is_wp_error($response)) {
            $last_error = $response;
            continue;
        }
        $status = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($raw_body, true);
        if (!is_array($decoded)) {
            $last_error = new WP_Error('webmcp_api_invalid_json', __('The WebMCP server returned invalid JSON.', 'webmcp-canary'));
            continue;
        }
        if ($status < 200 || $status >= 300 || empty($decoded['ok'])) {
            /* translators: %d: HTTP status code returned by the WebMCP server. */
            $message = !empty($decoded['message']) ? $decoded['message'] : (!empty($decoded['error']) ? $decoded['error'] : sprintf(__('HTTP %d', 'webmcp-canary'), $status));
            /* translators: %s: Error message returned by the WebMCP server. */
            return new WP_Error('webmcp_api_error', sprintf(__('The WebMCP server returned an error: %s', 'webmcp-canary'), $message), $decoded);
        }
        return $decoded;
    }

    return new WP_Error(
        'webmcp_api_unreachable',
        __('Could not connect to the WebMCP server. Check the tag.js URL, Docker status, or production Worker status.', 'webmcp-canary'),
        is_wp_error($last_error) ? array('detail' => $last_error->get_error_message()) : null
    );
}

function webmcp_canary_redirect_settings($status, $message) {
    $url = add_query_arg(
        array(
            'page' => 'webmcp-canary-settings',
            'webmcp_status' => sanitize_key($status),
            'webmcp_message' => rawurlencode($message),
        ),
        admin_url('admin.php')
    );
    $url = wp_nonce_url($url, 'webmcp_canary_notice');
    wp_safe_redirect($url);
    exit;
}

add_action('admin_post_webmcp_canary_issue_site_key', 'webmcp_canary_issue_site_key_action');
function webmcp_canary_issue_site_key_action() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to perform this action.', 'webmcp-canary'));
    }
    check_admin_referer('webmcp_canary_issue_site_key');
    $settings = webmcp_canary_settings();
    $result = webmcp_canary_api_request('api/site-key', array(
        'siteUrl' => home_url(),
        'email' => $settings['site_email'],
    ));
    if (is_wp_error($result)) {
        $data = $result->get_error_data();
        if (is_array($data) && isset($data['error']) && $data['error'] === 'duplicate_site_host' && !empty($data['existingSiteKey'])) {
            $settings['site_key'] = sanitize_text_field($data['existingSiteKey']);
            $settings['enabled'] = '1';
            update_option(WEBMCP_CANARY_OPTION, $settings);
            delete_transient('webmcp_canary_site_insights_' . md5(implode(',', webmcp_canary_api_base_candidates()) . '|' . $settings['site_key'] . '|' . home_url()));
            webmcp_canary_redirect_settings('updated', __('Saved the existing site key for this domain.', 'webmcp-canary'));
        }
        webmcp_canary_redirect_settings('error', $result->get_error_message());
    }
    $settings['site_key'] = sanitize_text_field($result['siteKey']);
    $settings['enabled'] = '1';
    update_option(WEBMCP_CANARY_OPTION, $settings);
    delete_transient('webmcp_canary_site_insights_' . md5(implode(',', webmcp_canary_api_base_candidates()) . '|' . $settings['site_key'] . '|' . home_url()));
    webmcp_canary_redirect_settings('updated', __('Issued and saved a free-plan site key.', 'webmcp-canary'));
}

add_action('admin_post_webmcp_canary_regenerate_site_key', 'webmcp_canary_regenerate_site_key_action');
function webmcp_canary_regenerate_site_key_action() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to perform this action.', 'webmcp-canary'));
    }
    check_admin_referer('webmcp_canary_regenerate_site_key');
    $settings = webmcp_canary_settings();
    if (empty($settings['site_key'])) {
        webmcp_canary_redirect_settings('error', __('There is no site key to regenerate.', 'webmcp-canary'));
    }
    $result = webmcp_canary_api_request('api/site-key/regenerate', array(
        'siteKey' => $settings['site_key'],
    ));
    if (is_wp_error($result)) {
        webmcp_canary_redirect_settings('error', $result->get_error_message());
    }
    $settings['site_key'] = sanitize_text_field($result['siteKey']);
    update_option(WEBMCP_CANARY_OPTION, $settings);
    webmcp_canary_redirect_settings('updated', __('Regenerated and saved the site key. The old key has been disabled.', 'webmcp-canary'));
}

add_action('admin_post_webmcp_canary_disable_site_key', 'webmcp_canary_disable_site_key_action');
function webmcp_canary_disable_site_key_action() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to perform this action.', 'webmcp-canary'));
    }
    check_admin_referer('webmcp_canary_disable_site_key');
    $settings = webmcp_canary_settings();
    if (empty($settings['site_key'])) {
        webmcp_canary_redirect_settings('error', __('There is no site key to disable.', 'webmcp-canary'));
    }
    $result = webmcp_canary_api_request('api/site-key/disable', array(
        'siteKey' => $settings['site_key'],
    ));
    if (is_wp_error($result)) {
        webmcp_canary_redirect_settings('error', $result->get_error_message());
    }
    $settings['site_key'] = '';
    $settings['enabled'] = '0';
    update_option(WEBMCP_CANARY_OPTION, $settings);
    webmcp_canary_redirect_settings('updated', __('Disabled the site key.', 'webmcp-canary'));
}

function webmcp_canary_get_site_insights($force_refresh = false) {
    $settings = webmcp_canary_settings();
    if (empty($settings['site_key'])) {
        return new WP_Error('webmcp_missing_site_key', __('The site key is not configured. Open WebMCP > Settings and configure it.', 'webmcp-canary'));
    }
    $api_bases = webmcp_canary_api_base_candidates();
    if (empty($api_bases)) {
        return new WP_Error('webmcp_missing_api_base', __('The tag.js URL is not configured. Open WebMCP > Settings and configure it.', 'webmcp-canary'));
    }

    $cache_key = 'webmcp_canary_site_insights_' . md5(implode(',', $api_bases) . '|' . $settings['site_key'] . '|' . home_url());
    if (!$force_refresh) {
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return $cached;
        }
    }

    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    $last_error = null;
    foreach ($api_bases as $api_base) {
        $url = add_query_arg(
            array(
                'site_key' => $settings['site_key'],
                'host' => $host,
            ),
            trailingslashit($api_base) . 'api/site-insights'
        );
        $response = wp_remote_get($url, array(
            'timeout' => 3,
            'headers' => array(
                'accept' => 'application/json',
            ),
        ));
        if (is_wp_error($response)) {
            $last_error = $response;
            continue;
        }
        $status = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $body = json_decode($raw_body, true);
        if ($status < 200 || $status >= 300) {
            /* translators: %d: HTTP status code returned by the WebMCP server. */
            $message = is_array($body) && !empty($body['error']) ? $body['error'] : sprintf(__('HTTP %d', 'webmcp-canary'), $status);
            /* translators: %s: Error message returned by the WebMCP server. */
            $last_error = new WP_Error('webmcp_insights_http_error', sprintf(__('The WebMCP server returned an error: %s', 'webmcp-canary'), $message));
            continue;
        }
        if (!is_array($body)) {
            $last_error = new WP_Error('webmcp_insights_invalid_json', __('The WebMCP server returned invalid JSON.', 'webmcp-canary'));
            continue;
        }
        if (!webmcp_canary_validate_site_insights($body)) {
            $last_error = new WP_Error('webmcp_insights_invalid_shape', __('The WebMCP server response did not match the expected format.', 'webmcp-canary'));
            continue;
        }
        set_transient($cache_key, $body, 10 * MINUTE_IN_SECONDS);
        return $body;
    }

    if (is_wp_error($last_error)) {
        return new WP_Error(
            'webmcp_insights_unreachable',
            __('Could not connect to the WebMCP server. Check the tag.js URL, Docker status, and site key.', 'webmcp-canary'),
            array('detail' => $last_error->get_error_message())
        );
    }
    return new WP_Error('webmcp_insights_unreachable', __('Could not connect to the WebMCP server.', 'webmcp-canary'));
}

function webmcp_canary_validate_site_insights($body) {
    if (!is_array($body)) {
        return false;
    }
    if (!array_key_exists('dataSufficiency', $body) || !is_array($body['dataSufficiency'])) {
        return false;
    }
    $required_keys = array('currentSubmissions', 'requiredSubmissions', 'remainingSubmissions', 'sufficient');
    foreach ($required_keys as $key) {
        if (!array_key_exists($key, $body['dataSufficiency'])) {
            return false;
        }
    }
    if (!array_key_exists('suggestions', $body) || !is_array($body['suggestions'])) {
        return false;
    }
    if (array_key_exists('basicStats', $body) && !is_null($body['basicStats']) && !is_array($body['basicStats'])) {
        return false;
    }
    if (array_key_exists('benchmark', $body) && !is_null($body['benchmark']) && !is_array($body['benchmark'])) {
        return false;
    }
    return true;
}

function webmcp_canary_percent($value) {
    return number_format_i18n(round(floatval($value) * 100, 1), 1) . '%';
}

function webmcp_canary_should_force_refresh() {
    if (empty($_GET['webmcp_refresh'])) {
        return false;
    }
    $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
    return wp_verify_nonce($nonce, 'webmcp_canary_refresh');
}

function webmcp_canary_dashboard_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $insights = webmcp_canary_get_site_insights(webmcp_canary_should_force_refresh());
    $settings = webmcp_canary_settings();
    $price = intval($settings['monthly_price_yen']);
    if (!is_wp_error($insights) && !empty($insights['pricing']['monthlyYen'])) {
        $price = intval($insights['pricing']['monthlyYen']);
    }
    ?>
    <div class="wrap webmcp-dashboard">
        <h1><?php echo esc_html__('WebMCP', 'webmcp-canary'); ?></h1>
        <p>
            <a class="button" href="<?php echo esc_url(wp_nonce_url(add_query_arg('webmcp_refresh', '1', menu_page_url('webmcp-canary', false)), 'webmcp_canary_refresh')); ?>">
                <?php echo esc_html__('Refresh data', 'webmcp-canary'); ?>
            </a>
        </p>
        <?php webmcp_canary_dashboard_styles(); ?>

        <?php if (is_wp_error($insights)) : ?>
            <div class="notice notice-warning">
                <p><?php echo esc_html($insights->get_error_message()); ?></p>
                <?php $detail = $insights->get_error_data('webmcp_insights_unreachable'); ?>
                <?php if (!empty($detail['detail'])) : ?>
                    <p class="description"><?php echo esc_html($detail['detail']); ?></p>
                <?php endif; ?>
                <p><?php echo esc_html__('Open WebMCP > Settings and configure the public tag.js URL and site key.', 'webmcp-canary'); ?></p>
            </div>
        <?php elseif (empty($insights['dataSufficiency']['sufficient'])) : ?>
            <?php webmcp_canary_render_collecting($insights); ?>
        <?php else : ?>
            <?php webmcp_canary_render_ready_dashboard($insights, $price); ?>
        <?php endif; ?>
    </div>
    <?php
}

function webmcp_canary_render_collecting($insights) {
    $current = intval($insights['dataSufficiency']['currentSubmissions'] ?? 0);
    $required = intval($insights['dataSufficiency']['requiredSubmissions'] ?? 20);
    $remaining = intval($insights['dataSufficiency']['remainingSubmissions'] ?? max(0, $required - $current));
    ?>
    <div class="webmcp-panel">
        <h2><?php echo esc_html__('Collecting data', 'webmcp-canary'); ?></h2>
        <p class="webmcp-large">
            <?php
            echo esc_html(
                sprintf(
                    /* translators: 1: Current submission count. 2: Remaining submission count before analysis starts. */
                    __('%1$d form submissions collected / %2$d remaining before analysis starts', 'webmcp-canary'),
                    intval($current),
                    intval($remaining)
                )
            );
            ?>
        </p>
        <progress class="webmcp-progress" value="<?php echo esc_attr($current); ?>" max="<?php echo esc_attr($required); ?>"></progress>
        <h3><?php echo esc_html__('What appears after data is collected', 'webmcp-canary'); ?></h3>
        <ul class="webmcp-list">
            <li><?php echo esc_html__('Form completion rate and fields with frequent drop-off.', 'webmcp-canary'); ?></li>
            <li><?php echo esc_html__('Improvement points based on real validation errors.', 'webmcp-canary'); ?></li>
            <li><?php echo esc_html__('Estimated completion-rate change after applying improvements.', 'webmcp-canary'); ?></li>
        </ul>
        <p class="description"><?php echo esc_html__('When the sample size is too low, the dashboard does not show guessed suggestions or inflated numbers.', 'webmcp-canary'); ?></p>
    </div>
    <?php
}

function webmcp_canary_render_ready_dashboard($insights, $price) {
    $stats = $insights['basicStats'];
    $suggestions = is_array($insights['suggestions'] ?? null) ? $insights['suggestions'] : array();
    ?>
    <div class="webmcp-grid">
        <div class="webmcp-card">
            <span class="webmcp-label"><?php echo esc_html__('Form submissions this month', 'webmcp-canary'); ?></span>
            <strong><?php echo esc_html(number_format_i18n(intval($stats['monthlySubmissions'] ?? 0))); ?></strong>
        </div>
        <div class="webmcp-card">
            <span class="webmcp-label"><?php echo esc_html__('Completion rate', 'webmcp-canary'); ?></span>
            <strong><?php echo esc_html(webmcp_canary_percent($stats['completionRate'] ?? 0)); ?></strong>
        </div>
        <div class="webmcp-card">
            <span class="webmcp-label"><?php echo esc_html__('Top 3 drop-off fields', 'webmcp-canary'); ?></span>
            <?php webmcp_canary_render_dropoff_fields($stats['topDropoffFields'] ?? array()); ?>
        </div>
    </div>

    <div class="webmcp-panel webmcp-locked">
        <h2><?php echo esc_html__('Industry benchmark', 'webmcp-canary'); ?></h2>
        <p><?php echo esc_html__('Your completion rate', 'webmcp-canary'); ?>: <strong><?php echo esc_html(webmcp_canary_percent($stats['completionRate'] ?? 0)); ?></strong></p>
        <p><?php echo esc_html__('The Pro plan can show peer averages, ranking, and estimated post-improvement differences. No guessed benchmark is shown when peer data is insufficient.', 'webmcp-canary'); ?></p>
    </div>

    <div class="webmcp-panel">
        <h2><?php echo esc_html__('Improvement suggestions', 'webmcp-canary'); ?></h2>
        <?php if (empty($suggestions)) : ?>
            <p><?php echo esc_html__('There are enough submissions, but no real-data-based improvement suggestions yet.', 'webmcp-canary'); ?></p>
        <?php else : ?>
            <ol class="webmcp-suggestions">
                <?php foreach ($suggestions as $index => $suggestion) : ?>
                    <?php webmcp_canary_render_suggestion($suggestion, $index, $price); ?>
                <?php endforeach; ?>
            </ol>
        <?php endif; ?>
    </div>
    <div class="webmcp-pro-cta">
        <a class="button" href="#" aria-disabled="true"><?php echo esc_html__('About the Pro plan (coming soon)', 'webmcp-canary'); ?></a>
    </div>
    <?php
}

function webmcp_canary_render_dropoff_fields($fields) {
    if (empty($fields)) {
        echo '<p>' . esc_html__('No notable drop-off fields yet.', 'webmcp-canary') . '</p>';
        return;
    }
    echo '<ol class="webmcp-compact-list">';
    foreach (array_slice($fields, 0, 3) as $field) {
        printf(
            '<li><strong>%1$s</strong> <span>%2$s</span></li>',
            esc_html($field['key'] ?? $field['selector'] ?? ''),
            esc_html(
                sprintf(
                    /* translators: %d: Number of validation issues for a field. */
                    _n('%d issue', '%d issues', intval($field['failures'] ?? 0), 'webmcp-canary'),
                    intval($field['failures'] ?? 0)
                )
            )
        );
    }
    echo '</ol>';
}

function webmcp_canary_render_suggestion($suggestion, $index, $price) {
    $effect = intval($suggestion['expectedEffect']['value'] ?? 0);
    $basis = $suggestion['expectedEffect']['basis'] ?? '';
    $locked = $index > 0;
    ?>
    <li class="<?php echo $locked ? 'webmcp-suggestion webmcp-locked' : 'webmcp-suggestion'; ?>">
        <div>
            <h3><?php echo esc_html($suggestion['title'] ?? __('Improvement suggestion', 'webmcp-canary')); ?></h3>
            <p class="webmcp-effect">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %d: Expected completion-rate lift in percentage points. */
                        __('Expected effect: completion rate +%dpt', 'webmcp-canary'),
                        intval($effect)
                    )
                );
                ?>
            </p>
            <?php if (!$locked) : ?>
                <p><?php echo esc_html($suggestion['reason'] ?? ''); ?></p>
                <?php if (!empty($basis)) : ?>
                    <p class="description"><?php echo esc_html($basis); ?></p>
                <?php endif; ?>
                <button type="button" class="button button-primary" disabled><?php echo esc_html__('Apply for free (coming soon)', 'webmcp-canary'); ?></button>
            <?php else : ?>
                <p><?php echo esc_html__('The Pro plan can show this suggestion in detail and enable one-click automatic application.', 'webmcp-canary'); ?></p>
            <?php endif; ?>
        </div>
    </li>
    <?php
}

function webmcp_canary_dashboard_styles() {
    ?>
    <style>
        .webmcp-dashboard .webmcp-panel,
        .webmcp-dashboard .webmcp-card {
            background: #fff;
            border: 1px solid #dcdcde;
            border-radius: 8px;
            padding: 20px;
            margin: 16px 0;
        }
        .webmcp-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
        }
        .webmcp-card strong {
            display: block;
            font-size: 28px;
            margin-top: 8px;
        }
        .webmcp-label {
            color: #646970;
            font-size: 13px;
        }
        .webmcp-large {
            font-size: 20px;
        }
        .webmcp-progress {
            width: 100%;
            height: 14px;
            accent-color: #7c3aed;
        }
        .webmcp-list {
            list-style: disc;
            margin-left: 20px;
        }
        .webmcp-compact-list {
            margin: 8px 0 0 18px;
        }
        .webmcp-locked {
            position: relative;
            background: linear-gradient(180deg, #fff, #fbfaff);
        }
        .webmcp-suggestions {
            margin-left: 0;
        }
        .webmcp-suggestion {
            list-style: none;
            border-top: 1px solid #dcdcde;
            padding: 16px 0;
        }
        .webmcp-suggestion:first-child {
            border-top: 0;
        }
        .webmcp-effect {
            color: #5b21b6;
            font-weight: 600;
        }
        .webmcp-pro-cta {
            margin: 20px 0;
            text-align: right;
        }
        @media (max-width: 900px) {
            .webmcp-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <?php
}

function webmcp_canary_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $settings = webmcp_canary_settings();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Nurevo WebMCP Canary', 'webmcp-canary'); ?></h1>
        <p><?php echo esc_html__('Loads an external WebMCP tag for standard HTML forms and common WordPress form plugins.', 'webmcp-canary'); ?></p>
        <?php if (!empty($_GET['webmcp_message']) && !empty($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'webmcp_canary_notice')) : ?>
            <?php $webmcp_status = isset($_GET['webmcp_status']) ? sanitize_key(wp_unslash($_GET['webmcp_status'])) : ''; ?>
            <?php $webmcp_message = sanitize_text_field(wp_unslash($_GET['webmcp_message'])); ?>
            <?php $notice_class = ($webmcp_status === 'error') ? 'notice-error' : 'notice-success'; ?>
            <div class="notice <?php echo esc_attr($notice_class); ?> is-dismissible">
                <p><?php echo esc_html($webmcp_message); ?></p>
            </div>
        <?php endif; ?>
        <form action="options.php" method="post">
            <?php
            settings_fields('webmcp_canary');
            do_settings_sections('webmcp_canary');
            submit_button();
            ?>
        </form>
        <hr>
        <h2><?php echo esc_html__('Site key actions', 'webmcp-canary'); ?></h2>
        <p><?php echo esc_html__('Issue a free site key for this WordPress domain, save it automatically, or rotate/disable the current key.', 'webmcp-canary'); ?></p>
        <div>
            <?php if (empty($settings['site_key'])) : ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" style="display:inline-block">
                    <?php wp_nonce_field('webmcp_canary_issue_site_key'); ?>
                    <input type="hidden" name="action" value="webmcp_canary_issue_site_key">
                    <?php submit_button(__('Issue free site key', 'webmcp-canary'), 'primary', 'submit', false); ?>
                </form>
            <?php else : ?>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" style="display:inline-block;margin-right:8px">
                    <?php wp_nonce_field('webmcp_canary_regenerate_site_key'); ?>
                    <input type="hidden" name="action" value="webmcp_canary_regenerate_site_key">
                    <?php submit_button(__('Regenerate site key', 'webmcp-canary'), 'secondary', 'submit', false); ?>
                </form>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" style="display:inline-block">
                    <?php wp_nonce_field('webmcp_canary_disable_site_key'); ?>
                    <input type="hidden" name="action" value="webmcp_canary_disable_site_key">
                    <?php submit_button(__('Disable site key', 'webmcp-canary'), 'delete', 'submit', false); ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

add_action('wp_enqueue_scripts', 'webmcp_canary_enqueue_tag');
function webmcp_canary_enqueue_tag() {
    if (is_admin()) {
        return;
    }
    $settings = webmcp_canary_settings();
    if ($settings['enabled'] !== '1' || empty($settings['tag_url'])) {
        return;
    }

    wp_enqueue_script(
        'webmcp-canary-tag',
        esc_url_raw($settings['tag_url']),
        array(),
        WEBMCP_CANARY_VERSION,
        false
    );
}

add_filter('script_loader_tag', 'webmcp_canary_script_loader_tag', 10, 3);
function webmcp_canary_script_loader_tag($tag, $handle, $src) {
    if ($handle !== 'webmcp-canary-tag') {
        return $tag;
    }
    $settings = webmcp_canary_settings();
    $site_key = $settings['site_key'];
    $attrs = array(
        'src' => esc_url($src),
        'async' => 'async',
        'data-webmcp-platform' => 'wordpress',
    );
    if (!empty($site_key)) {
        $attrs['data-webmcp-site-key'] = esc_attr($site_key);
    }
    $parts = array();
    foreach ($attrs as $name => $value) {
        if ($name === 'async') {
            $parts[] = 'async';
        } else {
            $parts[] = sprintf('%s="%s"', esc_attr($name), esc_attr($value));
        }
    }
    return '<script ' . implode(' ', $parts) . '></script>';
}
